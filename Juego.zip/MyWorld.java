import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    public contador puntos;
    public contador nivel;
    
    public int velocidadPez;
    public int obstaculosAdelantados;
    public int obstaculosAdelantadosPorNivel;
    public Pez pez;
    public int cantidadObstaculos;
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 700, 1);
        
       obstaculosAdelantados = 0;
       obstaculosAdelantadosPorNivel = 4;
       velocidadPez = 2;
       
       puntos = new contador("Puntos: " );
       nivel = new contador("Nivel: " );
       nivel.add(1);
       pez = new Pez(velocidadPez);
       
       addObject(pez, 300, 600);
       addObject(nivel, 205, 90);
       addObject(puntos, 205, 60);
    }
    
    public void act(){
        aumentar_dificultad();
        aniadir_rivales();
    }
    
    public int getRandomNumber(int start,int end){
       int normal = Greenfoot.getRandomNumber(end-start+1);
       return normal+start;
    }
    
    public void aumentarPuntuacion(int valor){
        puntos.add(valor);
    }
    
    public void aumentarObstaculosAdelantados(){
        obstaculosAdelantados++;
    }
    
    public void disminuir_cantidadObstaculos(){
        cantidadObstaculos--;
    }
    
    
    public void aumentar_dificultad(){
        if(obstaculosAdelantados == obstaculosAdelantadosPorNivel){
            obstaculosAdelantados = 0;
            obstaculosAdelantadosPorNivel = obstaculosAdelantadosPorNivel + 2;
            velocidadPez++;
            nivel.add(1);
            pez.aumenta_velocidad();
        }
    }
   
    public void aniadir_rivales(){
        
        if(cantidadObstaculos == 0){
            
            int carril = getRandomNumber(0,3);
            
            if(carril == 0){
                addObject(new ferrari(velocidadPez),180, 80);
            }
            else if( carril == 1){
                addObject(new ferrari(velocidadPez),290, 80);
            }
            else{
                addObject(new ferrari(velocidadPez),410, 80);
            }
            
            carril++;
            carril = carril % 3;
            
            if(carril == 0){
                addObject(new ferrari(velocidadPez),180, 80);
            }
            else if( carril == 1){
                addObject(new ferrari(velocidadPez),290, 80);
            }
            else{
                addObject(new ferrari(velocidadPez),410, 80);
            }
            
            
            cantidadObstaculos = 2;
        }
    }
    
    
    
}

